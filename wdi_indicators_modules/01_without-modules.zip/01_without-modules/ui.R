library("DT")

countries_list <- c("Afghanistan", "Albania", "Angola", "Argentina", "Austria", 
                    "Australia", "Bosnia and Herzegovina", "Bangladesh", "Belgium", 
                    "Burkina Faso", "Bulgaria", "Bahrain", "Burundi", "Benin", "Bolivia", 
                    "Brazil", "Botswana", "Canada", "Congo, Dem. Rep.", "Central African Republic", 
                    "Congo, Rep.", "Switzerland", "Cote d'Ivoire", "Chile", "Cameroon", 
                    "China", "Colombia", "Costa Rica", "Cuba", "Czech Republic", 
                    "Germany", "Djibouti", "Denmark", "Dominican Republic", "Algeria", 
                    "Ecuador", "Egypt, Arab Rep.", "Eritrea", "Spain", "Ethiopia", 
                    "Finland", "France", "Gabon", "United Kingdom", "Ghana", "Gambia, The", 
                    "Guinea", "Equatorial Guinea", "Greece", "Guatemala", "Guinea-Bissau", 
                    "Hong Kong SAR, China", "Honduras", "Croatia", "Haiti", "Hungary", 
                    "Indonesia", "Ireland", "Israel", "India", "Iraq", "Iran, Islamic Rep.", 
                    "Iceland", "Italy", "Jamaica", "Jordan", "Japan", "Kenya", "Cambodia", 
                    "Comoros", "Korea, Rep.", "Kuwait", "Lebanon", "Sri Lanka", "Liberia", 
                    "Lesotho", "Libya", "Morocco", "Montenegro", "Madagascar", "Mali", 
                    "Myanmar", "Mongolia", "Mauritania", "Mauritius", "Malawi", "Mexico", 
                    "Malaysia", "Mozambique", "Namibia", "Niger", "Nigeria", "Nicaragua", 
                    "Netherlands", "Norway", "Nepal", "New Zealand", "Oman", "Panama", 
                    "Peru", "Philippines", "Pakistan", "Poland", "Puerto Rico", "West Bank and Gaza", 
                    "Portugal", "Paraguay", "Romania", "Serbia", "Rwanda", "Saudi Arabia", 
                    "Sudan", "Sweden", "Singapore", "Slovenia", "Slovak Republic", 
                    "Sierra Leone", "Senegal", "Somalia", "Sao Tome and Principe", 
                    "El Salvador", "Syrian Arab Republic", "Eswatini", "Chad", "Togo", 
                    "Thailand", "Tunisia", "Turkey", "Trinidad and Tobago", "Tanzania", 
                    "Uganda", "United States", "Uruguay", "Venezuela, RB", "Vietnam", 
                    "Yemen, Rep.", "South Africa", "Zambia", "Zimbabwe")


navbarPage(
  "WDI",
  tabPanel(
    "Internet",
    fluidPage(
      selectInput("internet_country",
                  "Select a country",
                  choices = countries_list),
      plotOutput("internet_users_timeline"),
      uiOutput("internet_users_ranking_table")
    )
  ),
  tabPanel(
    "Bank branches",
    fluidPage(
      selectInput("bank_branches_country",
                  "Select a country",
                  choices = countries_list),
      plotOutput("bank_branches_timeline"),
      uiOutput("bank_branches_ranking_table")
    )
  ),
  collapsible = TRUE
)
